from datetime import datetime, timedelta

from lib.config import TIMEZONE, COMPETITIONS, validate_environment
from lib.log import log
from lib.espn_client import get_summary
from lib.supabase_client import upsert, select


# ============================================================
# STAT FIELD MAPPINGS (confirmed against real ESPN responses)
# ============================================================

TEAM_STAT_MAP = {
    "foulsCommitted": "fouls_committed",
    "yellowCards": "yellow_cards",
    "redCards": "red_cards",
    "offsides": "offsides",
    "wonCorners": "corners",
    "saves": "saves",
    "possessionPct": "possession_pct",
    "totalShots": "total_shots",
    "shotsOnTarget": "shots_on_target",
    "shotPct": "shot_pct",
    "penaltyKickGoals": "penalty_goals",
    "penaltyKickShots": "penalty_shots",
    "accuratePasses": "accurate_passes",
    "totalPasses": "total_passes",
    "passPct": "pass_pct",
    "accurateCrosses": "accurate_crosses",
    "totalCrosses": "total_crosses",
    "crossPct": "cross_pct",
    "totalLongBalls": "total_long_balls",
    "accurateLongBalls": "accurate_long_balls",
    "longballPct": "long_ball_pct",
    "blockedShots": "blocked_shots",
    "effectiveTackles": "effective_tackles",
    "totalTackles": "total_tackles",
    "tacklePct": "tackle_pct",
    "interceptions": "interceptions",
    "effectiveClearance": "effective_clearances",
    "totalClearance": "total_clearances",
}

PLAYER_STAT_MAP = {
    "appearances": "appearances",
    "foulsCommitted": "fouls_committed",
    "foulsSuffered": "fouls_suffered",
    "yellowCards": "yellow_cards",
    "redCards": "red_cards",
    "goalsConceded": "goals_conceded",
    "saves": "saves",
    "shotsFaced": "shots_faced",
    "goalAssists": "goal_assists",
    "shotsOnTarget": "shots_on_target",
    "totalGoals": "total_goals",
    "totalShots": "total_shots",
}


def stat_value(stat):
    """يرجع رقم من عنصر إحصائية ESPN (value لو موجودة، وإلا displayValue)."""

    if stat.get("value") is not None:
        return stat["value"]

    display = stat.get("displayValue")

    try:
        return float(display)
    except (TypeError, ValueError):
        return None


def map_stats(stat_list, field_map):

    mapped = {}

    for stat in stat_list:

        name = stat.get("name")

        if name in field_map:
            mapped[field_map[name]] = stat_value(stat)

    return mapped


# ============================================================
# PLAYER UPSERT HELPER (shared across lineups/stats/events)
# ============================================================

def upsert_players_get_ids(athletes, team_db_id):
    """athletes: list of ESPN athlete dicts (لازم فيها id + fullName).
    بيرجع {source_player_id: internal_players_id}."""

    records = []

    for athlete in athletes:

        source_id = str(athlete.get("id") or "")
        name = athlete.get("fullName") or athlete.get("displayName")

        if not source_id or not name:
            continue

        records.append({
            "source": "espn",
            "source_id": source_id,
            "name": name,
            "current_team_id": team_db_id,
        })

    if not records:
        return {}

    upsert("players", records, on_conflict="source,source_id")

    ids = list({r["source_id"] for r in records})

    rows = select(
        "players",
        {
            "select": "id,source_id",
            "source": "eq.espn",
            "source_id": f"in.({','.join(ids)})",
        },
    )

    return {row["source_id"]: row["id"] for row in rows}


def get_team_db_id(source_team_id):

    if not source_team_id:
        return None

    rows = select(
        "teams",
        {
            "select": "id",
            "source": "eq.espn",
            "source_id": f"eq.{source_team_id}",
        },
    )

    return rows[0]["id"] if rows else None


# ============================================================
# TEAM STATS (boxscore)
# ============================================================

def sync_team_stats(match_db_id, summary):

    boxscore = summary.get("boxscore") or {}

    records = []

    for team_block in boxscore.get("teams", []):

        source_team_id = str(
            (team_block.get("team") or {}).get("id") or ""
        )

        team_db_id = get_team_db_id(source_team_id)

        if not team_db_id:
            continue

        stat_list = team_block.get("statistics", [])

        record = {
            "match_id": match_db_id,
            "team_id": team_db_id,
            "home_away": team_block.get("homeAway"),
            "raw_stats": stat_list,
        }

        record.update(map_stats(stat_list, TEAM_STAT_MAP))

        records.append(record)

    if records:
        upsert("match_stats", records, on_conflict="match_id,team_id")

    return len(records)


# ============================================================
# ROSTERS -> LINEUPS + PLAYER STATS
# ============================================================

def sync_rosters(match_db_id, summary):

    rosters = summary.get("rosters") or []

    lineup_records = []
    player_stat_records = []

    for team_roster in rosters:

        source_team_id = str(
            (team_roster.get("team") or {}).get("id") or ""
        )

        team_db_id = get_team_db_id(source_team_id)

        roster = team_roster.get("roster", [])

        athletes = [
            entry.get("athlete", {})
            for entry in roster
            if entry.get("athlete")
        ]

        player_ids = upsert_players_get_ids(athletes, team_db_id)

        formation = team_roster.get("formation")
        home_away = team_roster.get("homeAway")

        for entry in roster:

            athlete = entry.get("athlete") or {}
            source_player_id = str(athlete.get("id") or "")

            player_db_id = player_ids.get(source_player_id)

            if not player_db_id:
                continue

            position = (
                (entry.get("position") or {}).get("name")
            )

            lineup_records.append({
                "match_id": match_db_id,
                "team_id": team_db_id,
                "home_away": home_away,
                "formation": formation,
                "player_id": player_db_id,
                "jersey_number": entry.get("jersey"),
                "position": position,
                "starter": bool(entry.get("starter")),
            })

            stat_list = entry.get("stats", [])

            if stat_list:

                stat_record = {
                    "match_id": match_db_id,
                    "player_id": player_db_id,
                    "team_id": team_db_id,
                    "starter": bool(entry.get("starter")),
                    "active": bool(entry.get("active", True)),
                    "jersey_number": entry.get("jersey"),
                    "position": position,
                    "formation_place": entry.get("formationPlace"),
                    "subbed_in": bool(entry.get("subbedIn")),
                    "subbed_out": bool(entry.get("subbedOut")),
                    "raw_stats": stat_list,
                }

                stat_record.update(
                    map_stats(stat_list, PLAYER_STAT_MAP)
                )

                player_stat_records.append(stat_record)

    if lineup_records:
        upsert(
            "match_lineups",
            lineup_records,
            on_conflict="match_id,player_id",
        )

    if player_stat_records:
        upsert(
            "player_match_stats",
            player_stat_records,
            on_conflict="match_id,player_id",
        )

    return len(lineup_records), len(player_stat_records)


# ============================================================
# LEADERS
# ============================================================

def sync_leaders(match_db_id, summary):

    leaders = summary.get("leaders") or []

    records = []

    for team_leaders in leaders:

        source_team_id = str(
            (team_leaders.get("team") or {}).get("id") or ""
        )

        team_db_id = get_team_db_id(source_team_id)

        for category in team_leaders.get("leaders", []):

            top = (category.get("leaders") or [None])[0]

            if not top:
                continue

            athlete = top.get("athlete") or {}

            player_ids = upsert_players_get_ids([athlete], team_db_id)

            player_db_id = player_ids.get(str(athlete.get("id") or ""))

            records.append({
                "match_id": match_db_id,
                "team_id": team_db_id,
                "player_id": player_db_id,
                "category": category.get("name") or category.get("displayName"),
                "value": top.get("value"),
                "display_value": top.get("displayValue"),
            })

    if records:
        upsert(
            "match_leaders",
            records,
            on_conflict="match_id,team_id,category",
        )

    return len(records)


# ============================================================
# EVENTS (keyEvents) — منطق مبني على تجربة سابقة ناجحة، لكن
# لسه محتاج تأكيد نهائي على نص "type" الحقيقي من ESPN لو ظهرت
# نتائج غريبة في اللوج (راجع أسلوبنا المعتاد في التشخيص).
# ============================================================

def extract_athletes(detail):

    participants = detail.get("participants") or []

    if participants:
        return [
            p.get("athlete", {})
            for p in participants
            if isinstance(p, dict) and p.get("athlete")
        ]

    return detail.get("athletesInvolved") or []


def classify_event_type(detail):

    type_text = (
        (detail.get("type") or {}).get("text", "")
    ).lower()

    if "goal" in type_text and "own" not in type_text:
        return "goal"
    if "yellow card" in type_text:
        return "yellow_card"
    if "red card" in type_text:
        return "red_card"
    if "substitution" in type_text:
        return "substitution"
    if "penalty" in type_text:
        return "penalty"
    if "var" in type_text or "video" in type_text:
        return "var"

    return None


def sync_events(match_db_id, summary, home_team_db_id, away_team_db_id):

    key_events = summary.get("keyEvents") or []

    records = []

    for index, detail in enumerate(key_events):

        event_type = classify_event_type(detail)

        if not event_type:
            continue

        team_source_id = str(
            (detail.get("team") or {}).get("id") or ""
        )

        team_db_id = get_team_db_id(team_source_id)

        athletes = extract_athletes(detail)

        player_ids = upsert_players_get_ids(athletes, team_db_id)

        def pid(athlete):
            return player_ids.get(str(athlete.get("id") or ""))

        player_id = None
        assist_player_id = None
        player_out_id = None
        player_in_id = None

        if event_type == "substitution" and len(athletes) >= 2:
            player_in_id = pid(athletes[0])
            player_out_id = pid(athletes[1])
        else:
            if len(athletes) >= 1:
                player_id = pid(athletes[0])
            if len(athletes) >= 2:
                assist_player_id = pid(athletes[1])

        clock = (detail.get("clock") or {}).get("displayValue", "")

        minute = None
        extra_time = None

        if clock:

            clean = clock.replace("'", "")

            if "+" in clean:
                base, extra = clean.split("+", 1)
                minute = int(base) if base.isdigit() else None
                extra_time = int(extra) if extra.isdigit() else None
            elif clean.isdigit():
                minute = int(clean)

        records.append({
            "match_id": match_db_id,
            "team_id": team_db_id,
            "player_id": player_id,
            "assist_player_id": assist_player_id,
            "player_out_id": player_out_id,
            "player_in_id": player_in_id,
            "event_type": event_type,
            "minute": minute,
            "extra_time": extra_time,
            "details": detail,
            "source": "espn",
            "source_id": (
                f"{match_db_id}-{detail.get('id', index)}"
            ),
        })

    if records:
        upsert("match_events", records, on_conflict="source,source_id")

    return len(records)


# ============================================================
# MATCH SELECTION
# ============================================================

def get_league_slug_for_competition(competition_id, competition_id_to_slug):
    return competition_id_to_slug.get(competition_id)


def get_matches_needing_detail_sync():

    today = datetime.now(TIMEZONE).date()

    start = (today - timedelta(days=1)).isoformat() + "T00:00:00"
    end = (today + timedelta(days=2)).isoformat() + "T00:00:00"

    rows = select(
        "matches",
        {
            "select": (
                "id,source_id,status,competition_id,"
                "home_team_id,away_team_id"
            ),
            "kickoff_at": [f"gte.{start}", f"lt.{end}"],
        },
    )

    # نتجاهل الماتشات المنتهية اللي اتعملها تفاصيل خلاص، عشان
    # منضربش ESPN من غير داعي لحاجة خلصت وما هتتغيرش.
    finished_ids = [
        str(r["id"]) for r in rows if r["status"] == "FINISHED"
    ]

    already_has_stats = set()

    if finished_ids:

        existing = select(
            "match_stats",
            {
                "select": "match_id",
                "match_id": f"in.({','.join(finished_ids)})",
            },
        )

        already_has_stats = {row["match_id"] for row in existing}

    return [
        r for r in rows
        if not (r["status"] == "FINISHED" and r["id"] in already_has_stats)
    ]


def main():

    validate_environment()

    log("==================================================")
    log("SYNC MATCH DETAILS START")
    log("==================================================")

    competitions = select(
        "competitions", {"select": "id,source_id"}
    )

    competition_slug_map = {
        c["id"]: c["source_id"] for c in competitions
    }

    matches = get_matches_needing_detail_sync()

    log(f"Matches needing detail sync: {len(matches)}")

    for match in matches:

        match_db_id = match["id"]
        league_slug = competition_slug_map.get(match["competition_id"])

        if not league_slug:
            log(
                f"WARNING: no league slug for match={match_db_id}, "
                f"skipping."
            )
            continue

        try:

            summary = get_summary(league_slug, match["source_id"])

            events_count = sync_events(
                match_db_id,
                summary,
                match.get("home_team_id"),
                match.get("away_team_id"),
            )

            stats_count = sync_team_stats(match_db_id, summary)

            lineup_count, player_stat_count = sync_rosters(
                match_db_id, summary
            )

            leaders_count = sync_leaders(match_db_id, summary)

            log(
                f"match={match_db_id}: "
                f"events={events_count}, "
                f"team_stats={stats_count}, "
                f"lineups={lineup_count}, "
                f"player_stats={player_stat_count}, "
                f"leaders={leaders_count}"
            )

        except Exception as error:
            log(f"ERROR match={match_db_id}: {error}")
            continue

    log("==================================================")
    log("SYNC MATCH DETAILS END")
    log("==================================================")


if __name__ == "__main__":
    main()
